"""Tooling for the Fleet Device Management REST API.

Submodules:
    auth: Load Fleet API credentials from the environment, build an
        authenticated HTTP client, and verify the token against the
        Fleet server.
    labels: Add or remove manual labels on a set of hosts.
"""

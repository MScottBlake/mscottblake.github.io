"""Authenticate against the Fleet Device Management REST API.

This module reads a Fleet server URL and API token from the environment,
builds an ``httpx.Client`` that sends the token on every request, and
verifies the token by calling ``GET /api/v1/fleet/me``.

Required environment variables:
    FLEET_URL: Base URL of the Fleet server, e.g. ``https://fleet.example.com``.
    FLEET_API_TOKEN: A Fleet API token. For a human user, copy one from the
        Fleet UI under "My account" > "Get API token". For a service
        account, create one with
        ``fleetctl user create --name "svc" --api-only``.

Invocation examples:
    Check that the token in the environment is valid::

        $ export FLEET_URL=https://fleet.example.com
        $ export FLEET_API_TOKEN=xxxxx
        $ uv run fleet-auth check
        Authenticated as Jane Doe <jane@example.com> (role: admin)

    Same check, machine-readable output::

        $ uv run fleet-auth check --json
        {"id": 1, "name": "Jane Doe", "email": "jane@example.com", ...}

    Run as a module instead of the installed script::

        $ uv run python -m fleet_mgmt.auth check

    Use the module as a library to build a client for other Fleet API
    calls::

        from fleet_mgmt.auth import build_client, load_credentials, verify_token

        credentials = load_credentials()
        with build_client(credentials) as client:
            user = verify_token(client)
            print(user.email)
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any
from urllib.parse import urlsplit

import httpx

if TYPE_CHECKING:
    from collections.abc import Sequence

_ME_PATH = "/api/v1/fleet/me"


class FleetAuthError(Exception):
    """Base class for authentication errors raised by this module."""


class MissingCredentialsError(FleetAuthError):
    """Raised when ``FLEET_URL`` or ``FLEET_API_TOKEN`` is missing or invalid."""


class InvalidTokenError(FleetAuthError):
    """Raised when the Fleet server rejects the token as invalid or expired."""


class RateLimitedError(FleetAuthError):
    """Raised when the Fleet server responds with HTTP 429.

    Attributes:
        retry_after: Seconds to wait before retrying, if the server sent a
            ``Retry-After`` header, otherwise ``None``.
    """

    def __init__(self, retry_after: float | None) -> None:
        """Initialize the error.

        Args:
            retry_after: Seconds to wait before retrying, or ``None`` if the
                server did not send a ``Retry-After`` header.
        """
        self.retry_after = retry_after
        message = "Fleet API rate limit exceeded"
        if retry_after is not None:
            message = f"{message}; retry after {retry_after:g}s"
        super().__init__(message)


class FleetAPIError(FleetAuthError):
    """Raised when the Fleet server responds with an unexpected error status.

    Attributes:
        status_code: The HTTP status code returned by the server.
    """

    def __init__(self, status_code: int, message: str) -> None:
        """Initialize the error.

        Args:
            status_code: The HTTP status code returned by the server.
            message: A human-readable description of the failure.
        """
        self.status_code = status_code
        super().__init__(f"Fleet API error ({status_code}): {message}")


@dataclass(frozen=True, slots=True)
class FleetCredentials:
    """Credentials used to authenticate against a Fleet server.

    Attributes:
        base_url: The Fleet server's base URL, with no trailing slash.
        token: The bearer token sent with every request.
    """

    base_url: str
    token: str = field(repr=False)


@dataclass(frozen=True, slots=True)
class FleetUser:
    """A Fleet user, as returned by ``GET /api/v1/fleet/me``.

    Attributes:
        id: The user's numeric ID.
        name: The user's display name.
        email: The user's email address.
        global_role: The user's global role (e.g. ``"admin"``), or ``None``
            if the user only has team-level roles.
        api_only: ``True`` if this is a service account created with
            ``fleetctl user create --api-only``.
    """

    id: int
    name: str
    email: str
    global_role: str | None
    api_only: bool


def load_credentials(env: Mapping[str, str] | None = None) -> FleetCredentials:
    """Load Fleet credentials from environment variables.

    Args:
        env: A mapping to read ``FLEET_URL`` and ``FLEET_API_TOKEN`` from.
            Defaults to ``os.environ``. Passing an explicit mapping keeps
            this function pure for testing.

    Returns:
        The loaded credentials, with the base URL stripped of any trailing
        slash.

    Raises:
        MissingCredentialsError: If ``FLEET_URL`` or ``FLEET_API_TOKEN`` is
            unset or blank, or if ``FLEET_URL`` is not a valid ``http`` or
            ``https`` URL with a host.
    """
    source = os.environ if env is None else env

    base_url = source.get("FLEET_URL", "").strip()
    if not base_url:
        message = "FLEET_URL environment variable is not set"
        raise MissingCredentialsError(message)

    parsed = urlsplit(base_url)
    if parsed.scheme not in {"http", "https"} or not parsed.netloc:
        message = f"FLEET_URL must be a valid http(s) URL, got: {base_url!r}"
        raise MissingCredentialsError(message)

    token = source.get("FLEET_API_TOKEN", "").strip()
    if not token:
        message = "FLEET_API_TOKEN environment variable is not set"
        raise MissingCredentialsError(message)

    return FleetCredentials(base_url=base_url.rstrip("/"), token=token)


def auth_headers(credentials: FleetCredentials) -> dict[str, str]:
    """Build the HTTP headers needed to authenticate a Fleet API request.

    Args:
        credentials: The credentials to authenticate with.

    Returns:
        A headers mapping with a ``Bearer`` authorization header and an
        ``Accept: application/json`` header.
    """
    return {
        "Authorization": f"Bearer {credentials.token}",
        "Accept": "application/json",
    }


def build_client(
    credentials: FleetCredentials,
    *,
    timeout: float = 30.0,
    transport: httpx.BaseTransport | None = None,
) -> httpx.Client:
    """Build an ``httpx.Client`` authenticated against a Fleet server.

    Args:
        credentials: The credentials to authenticate with.
        timeout: Request timeout, in seconds.
        transport: An optional custom transport, used in tests to avoid
            real network calls.

    Returns:
        A configured, not-yet-opened ``httpx.Client``. Callers are
        responsible for closing it, typically with a ``with`` statement.
    """
    return httpx.Client(
        base_url=credentials.base_url,
        headers=auth_headers(credentials),
        timeout=timeout,
        transport=transport,
    )


def verify_token(client: httpx.Client) -> FleetUser:
    """Verify the client's token by calling ``GET /api/v1/fleet/me``.

    Args:
        client: An authenticated client, as returned by :func:`build_client`.

    Returns:
        The authenticated user.

    Raises:
        InvalidTokenError: If the server responds with HTTP 401.
        RateLimitedError: If the server responds with HTTP 429.
        FleetAPIError: If the server responds with any other non-2xx status.
        httpx.HTTPError: If the request itself fails (e.g. connection error).
    """
    response = client.get(_ME_PATH)
    raise_for_status(response)
    return _parse_user(response.json()["user"])


def raise_for_status(response: httpx.Response) -> None:
    """Translate a non-2xx Fleet API response into a specific exception.

    Shared across ``fleet_mgmt`` modules so every Fleet API call maps HTTP
    status codes to the same exception types.

    Args:
        response: The HTTP response to check.

    Raises:
        InvalidTokenError: If the status code is 401.
        RateLimitedError: If the status code is 429.
        FleetAPIError: If the status code is any other non-2xx value.
    """
    if response.status_code == httpx.codes.UNAUTHORIZED:
        message = "Fleet API token is invalid or expired"
        raise InvalidTokenError(message)

    if response.status_code == httpx.codes.TOO_MANY_REQUESTS:
        retry_after_header = response.headers.get("Retry-After")
        retry_after = float(retry_after_header) if retry_after_header else None
        raise RateLimitedError(retry_after)

    if response.is_success:
        return

    try:
        body = response.json()
    except ValueError:
        body = None
    message = _error_message(body) if isinstance(body, Mapping) else None

    raise FleetAPIError(response.status_code, message or response.text)


def _error_message(body: Mapping[str, Any]) -> str | None:
    """Build a readable message from a Fleet JSON error body.

    Fleet puts a generic summary in ``message`` (for example "Bad request")
    and the specific cause in ``errors[].reason``. Both are joined so the
    caller sees why the request failed.

    Args:
        body: The decoded JSON error body.

    Returns:
        ``"<message>: <reason>; <reason>"``, or only the parts present, or
        ``None`` if the body has neither.
    """
    summary = str(body.get("message") or "")
    errors = body.get("errors")
    reasons: list[str] = []
    if isinstance(errors, list):
        reasons = [
            str(error["reason"])
            for error in errors
            if isinstance(error, Mapping) and error.get("reason")
        ]
    detail = "; ".join(reasons)
    if summary and detail:
        return f"{summary}: {detail}"
    return summary or detail or None


def _parse_user(data: Mapping[str, Any]) -> FleetUser:
    """Parse a Fleet API ``user`` object into a :class:`FleetUser`.

    Args:
        data: The ``user`` field from a Fleet API response body. Typed as
            ``Any``-valued because it is untrusted JSON crossing a process
            boundary; every field is explicitly converted below.

    Returns:
        The parsed user.
    """
    return FleetUser(
        id=int(data["id"]),
        name=str(data["name"]),
        email=str(data["email"]),
        global_role=None if data.get("global_role") is None else str(data["global_role"]),
        api_only=bool(data.get("api_only", False)),
    )


def _build_arg_parser() -> argparse.ArgumentParser:
    """Build the command-line argument parser for this module.

    Returns:
        A configured ``argparse.ArgumentParser``.
    """
    parser = argparse.ArgumentParser(
        prog="fleet-auth",
        description="Check Fleet Device Management API credentials.",
    )
    subparsers = parser.add_subparsers(dest="command")
    check_parser = subparsers.add_parser(
        "check",
        help="Verify FLEET_URL and FLEET_API_TOKEN against the Fleet server.",
    )
    check_parser.add_argument(
        "--json",
        action="store_true",
        help="Print the authenticated user as JSON instead of plain text.",
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """Run the ``fleet-auth`` command-line tool.

    Args:
        argv: Command-line arguments, excluding the program name. Defaults
            to ``sys.argv[1:]``.

    Returns:
        A process exit code: ``0`` on success, ``2`` for missing or invalid
        credentials, ``3`` for an invalid or expired token, ``4`` for a
        rate-limited request, and ``1`` for any other API or network error.
    """
    parser = _build_arg_parser()
    args = parser.parse_args(argv)
    command = args.command or "check"

    if command != "check":  # pragma: no cover - argparse rejects unknown commands
        parser.error(f"unknown command: {command}")

    try:
        credentials = load_credentials()
    except MissingCredentialsError as error:
        print(f"error: {error}", file=sys.stderr)
        return 2

    try:
        with build_client(credentials) as client:
            user = verify_token(client)
    except InvalidTokenError as error:
        print(f"error: {error}", file=sys.stderr)
        return 3
    except RateLimitedError as error:
        print(f"error: {error}", file=sys.stderr)
        return 4
    except (FleetAPIError, httpx.HTTPError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 1

    if getattr(args, "json", False):
        print(
            json.dumps(
                {
                    "id": user.id,
                    "name": user.name,
                    "email": user.email,
                    "global_role": user.global_role,
                    "api_only": user.api_only,
                },
            ),
        )
    else:
        print(f"Authenticated as {user.name} <{user.email}> (role: {user.global_role})")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

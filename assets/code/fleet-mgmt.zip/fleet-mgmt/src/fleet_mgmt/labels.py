"""Manage Fleet manual labels: create or delete them, and add or remove them on hosts.

Host commands (``add``, ``remove``) resolve each host identifier (hostname,
hardware serial, or UUID) to a Fleet host ID via
``GET /api/v1/fleet/hosts/identifier/{id}``, then call ``POST`` or
``DELETE /api/v1/fleet/hosts/{id}/labels`` for each host in turn. Only
manual labels can be assigned this way; Fleet rejects dynamic
(query-based) and builtin labels with a 400 response.

Label commands (``create``, ``delete``) manage the labels themselves.
``create`` calls ``POST /api/v1/fleet/labels`` with a manual membership
type. ``delete`` looks up label IDs once via
``GET /api/v1/fleet/labels/summary`` and then calls
``DELETE /api/v1/fleet/labels/id/{id}``. Deleting by ID rather than by name
works for names that contain ``/``, which Fleet's by-name route cannot
match. Fleet refuses to delete builtin labels with a 422 response.

A failure on one host or label (host not found, unknown label, label is
dynamic, duplicate name) does not stop the run: it is recorded and the next
item is tried. A failure that would affect every remaining item (an invalid
token, a rate limit) stops the run immediately.

Required environment variables:
    FLEET_URL: Base URL of the Fleet server, e.g. ``https://fleet.example.com``.
    FLEET_API_TOKEN: A Fleet API token with the maintainer, admin,
        technician, or gitops role. See :mod:`fleet_mgmt.auth` for how to
        obtain one.

Invocation examples:
    Add a label to two hosts by hostname::

        $ export FLEET_URL=https://fleet.example.com
        $ export FLEET_API_TOKEN=xxxxx
        $ uv run fleet-labels add --label canary web-01 web-02
        ok   web-01 (host 12)
        ok   web-02 (host 13)
        2 succeeded, 0 failed

    Remove two labels from a host identified by hardware serial::

        $ uv run fleet-labels remove --label canary --label beta C02XK1ABJG5H
        ok   C02XK1ABJG5H (host 41)
        1 succeeded, 0 failed

    Read hosts from a file, one identifier per line, and get JSON output::

        $ uv run fleet-labels add --label canary --file hosts.txt --json
        {"action": "add", "labels": ["canary"], "succeeded": 2, "failed": 0, ...}

    Read hosts from standard input::

        $ cat hosts.txt | uv run fleet-labels add --label canary --file -

    Create two manual labels with a shared description::

        $ uv run fleet-labels create canary beta --description "Early rollout ring"
        ok   canary (label 21)
        ok   beta (label 22)
        2 succeeded, 0 failed

    Delete a label (``--yes`` is required because deletion is permanent)::

        $ uv run fleet-labels delete canary --yes
        ok   canary (label 21)
        1 succeeded, 0 failed

    Run as a module instead of the installed script::

        $ uv run python -m fleet_mgmt.labels add --label canary web-01

    Use the module as a library::

        from fleet_mgmt.auth import build_client, load_credentials
        from fleet_mgmt.labels import LabelAction, create_labels, delete_labels, update_labels

        with build_client(load_credentials()) as client:
            create_labels(client, ["canary"], description="Early rollout ring")
            results = update_labels(client, ["web-01", "web-02"], ["canary"], LabelAction.ADD)
            failures = [result for result in results if not result.ok]
            delete_labels(client, ["canary"])
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING
from urllib.parse import quote

import httpx

from fleet_mgmt.auth import (
    FleetAPIError,
    InvalidTokenError,
    MissingCredentialsError,
    RateLimitedError,
    build_client,
    load_credentials,
    raise_for_status,
)

if TYPE_CHECKING:
    from collections.abc import Iterable, Sequence

_HOSTS_IDENTIFIER_PATH = "/api/v1/fleet/hosts/identifier/{identifier}"
_HOST_LABELS_PATH = "/api/v1/fleet/hosts/{host_id}/labels"
_LABELS_PATH = "/api/v1/fleet/labels"
_LABELS_SUMMARY_PATH = "/api/v1/fleet/labels/summary"
_LABEL_BY_ID_PATH = "/api/v1/fleet/labels/id/{label_id}"

_CREATE = "create"
_DELETE = "delete"


class LabelAction(StrEnum):
    """Which label operation to perform on a host.

    Attributes:
        ADD: Assign the given labels to a host.
        REMOVE: Unassign the given labels from a host.
    """

    ADD = "add"
    REMOVE = "remove"


class LabelError(Exception):
    """Base class for errors raised by this module."""


class HostNotFoundError(LabelError):
    """Raised when no Fleet host matches a given identifier."""


@dataclass(frozen=True, slots=True)
class LabelResult:
    """The outcome of creating or deleting one label.

    Attributes:
        name: The label name the caller supplied.
        label_id: The Fleet label ID, or ``None`` if the operation failed
            before an ID was known.
        error: A human-readable failure reason, or ``None`` on success.
    """

    name: str
    label_id: int | None
    error: str | None

    @property
    def ok(self) -> bool:
        """Whether the label was created or deleted.

        Returns:
            ``True`` if there is no recorded error.
        """
        return self.error is None


@dataclass(frozen=True, slots=True)
class HostResult:
    """The outcome of applying a label action to one host.

    Attributes:
        identifier: The identifier the caller supplied for this host.
        host_id: The resolved Fleet host ID, or ``None`` if resolution
            failed.
        error: A human-readable failure reason, or ``None`` on success.
    """

    identifier: str
    host_id: int | None
    error: str | None

    @property
    def ok(self) -> bool:
        """Whether the label action succeeded for this host.

        Returns:
            ``True`` if there is no recorded error.
        """
        return self.error is None


def read_identifiers(lines: Iterable[str]) -> list[str]:
    """Parse host identifiers from a sequence of lines.

    Blank lines and lines starting with ``#`` are skipped. Duplicate
    identifiers are removed, keeping the first occurrence's position.

    Args:
        lines: Lines of text, such as from a file or standard input.

    Returns:
        The unique, ordered list of host identifiers.
    """
    seen: dict[str, None] = {}
    for line in lines:
        identifier = line.strip()
        if not identifier or identifier.startswith("#"):
            continue
        seen.setdefault(identifier, None)
    return list(seen)


def resolve_host_id(client: httpx.Client, identifier: str) -> int:
    """Resolve a host identifier to a Fleet host ID.

    Args:
        client: An authenticated client, as returned by
            :func:`fleet_mgmt.auth.build_client`.
        identifier: A hostname, hardware serial, UUID, node key, or
            osquery host ID.

    Returns:
        The numeric Fleet host ID.

    Raises:
        HostNotFoundError: If no host matches the identifier.
        InvalidTokenError: If the server responds with HTTP 401.
        RateLimitedError: If the server responds with HTTP 429.
        FleetAPIError: If the server responds with any other non-2xx status.
        httpx.HTTPError: If the request itself fails (e.g. connection error).
    """
    path = _HOSTS_IDENTIFIER_PATH.format(identifier=quote(identifier, safe=""))
    response = client.get(path, params={"exclude_software": "true"})

    if response.status_code == httpx.codes.NOT_FOUND:
        message = f"no host matches identifier {identifier!r}"
        raise HostNotFoundError(message)

    raise_for_status(response)
    return int(response.json()["host"]["id"])


def apply_labels(
    client: httpx.Client,
    host_id: int,
    labels: Sequence[str],
    action: LabelAction,
) -> None:
    """Add or remove labels on a single host.

    Args:
        client: An authenticated client, as returned by
            :func:`fleet_mgmt.auth.build_client`.
        host_id: The Fleet host ID to modify.
        labels: The manual label names to add or remove.
        action: Whether to add or remove the labels.

    Raises:
        InvalidTokenError: If the server responds with HTTP 401.
        RateLimitedError: If the server responds with HTTP 429.
        FleetAPIError: If a label does not exist, is not a manual label,
            or the server responds with any other non-2xx status.
        httpx.HTTPError: If the request itself fails (e.g. connection error).
    """
    method = "POST" if action is LabelAction.ADD else "DELETE"
    path = _HOST_LABELS_PATH.format(host_id=host_id)
    response = client.request(method, path, json={"labels": list(labels)})
    raise_for_status(response)


def update_labels(
    client: httpx.Client,
    identifiers: Iterable[str],
    labels: Sequence[str],
    action: LabelAction,
) -> list[HostResult]:
    """Apply a label action to a set of hosts, continuing past per-host errors.

    Each host is resolved and updated independently. A per-host failure
    (the host is not found, or the label is unknown or not a manual label)
    is recorded in that host's result and does not stop the run. An error
    that would affect every remaining host (an invalid token, a rate
    limit, or a network error) is raised immediately instead, since
    continuing would only repeat the same failure for each remaining host.

    Args:
        client: An authenticated client, as returned by
            :func:`fleet_mgmt.auth.build_client`.
        identifiers: Host identifiers to update, in order.
        labels: The manual label names to add or remove.
        action: Whether to add or remove the labels.

    Returns:
        One :class:`HostResult` per identifier, in the given order.

    Raises:
        InvalidTokenError: If the server responds with HTTP 401.
        RateLimitedError: If the server responds with HTTP 429.
        httpx.HTTPError: If a request fails (e.g. connection error).
    """
    results: list[HostResult] = []
    for identifier in identifiers:
        try:
            host_id = resolve_host_id(client, identifier)
            apply_labels(client, host_id, labels, action)
        except (HostNotFoundError, FleetAPIError) as error:
            results.append(HostResult(identifier, None, str(error)))
        else:
            results.append(HostResult(identifier, host_id, None))
    return results


def create_label(client: httpx.Client, name: str, description: str = "") -> int:
    """Create one manual label.

    Args:
        client: An authenticated client, as returned by
            :func:`fleet_mgmt.auth.build_client`.
        name: The new label's name.
        description: An optional description shown in the Fleet UI.

    Returns:
        The new label's Fleet ID.

    Raises:
        InvalidTokenError: If the server responds with HTTP 401.
        RateLimitedError: If the server responds with HTTP 429.
        FleetAPIError: If a label with this name already exists (409), the
            name is invalid (422), or the server responds with any other
            non-2xx status.
        httpx.HTTPError: If the request itself fails (e.g. connection error).
    """
    body = {"name": name, "description": description, "label_membership_type": "manual"}
    response = client.post(_LABELS_PATH, json=body)
    raise_for_status(response)
    return int(response.json()["label"]["id"])


def fetch_label_ids(client: httpx.Client) -> dict[str, int]:
    """Fetch the ID of every label the token can see, keyed by name.

    Args:
        client: An authenticated client, as returned by
            :func:`fleet_mgmt.auth.build_client`.

    Returns:
        A mapping of label name to Fleet label ID.

    Raises:
        InvalidTokenError: If the server responds with HTTP 401.
        RateLimitedError: If the server responds with HTTP 429.
        FleetAPIError: If the server responds with any other non-2xx status.
        httpx.HTTPError: If the request itself fails (e.g. connection error).
    """
    response = client.get(_LABELS_SUMMARY_PATH)
    raise_for_status(response)
    return {str(label["name"]): int(label["id"]) for label in response.json()["labels"]}


def delete_label(client: httpx.Client, label_id: int) -> None:
    """Delete one label by its Fleet ID.

    Args:
        client: An authenticated client, as returned by
            :func:`fleet_mgmt.auth.build_client`.
        label_id: The Fleet label ID to delete.

    Raises:
        InvalidTokenError: If the server responds with HTTP 401.
        RateLimitedError: If the server responds with HTTP 429.
        FleetAPIError: If the label is builtin (422), no longer exists
            (404), or the server responds with any other non-2xx status.
        httpx.HTTPError: If the request itself fails (e.g. connection error).
    """
    response = client.delete(_LABEL_BY_ID_PATH.format(label_id=label_id))
    raise_for_status(response)


def create_labels(
    client: httpx.Client,
    names: Iterable[str],
    description: str = "",
) -> list[LabelResult]:
    """Create manual labels, continuing past per-label errors.

    A per-label failure (the name already exists or is invalid) is recorded
    in that label's result and does not stop the run.

    Args:
        client: An authenticated client, as returned by
            :func:`fleet_mgmt.auth.build_client`.
        names: Label names to create, in order.
        description: A description applied to every created label.

    Returns:
        One :class:`LabelResult` per name, in the given order.

    Raises:
        InvalidTokenError: If the server responds with HTTP 401.
        RateLimitedError: If the server responds with HTTP 429.
        httpx.HTTPError: If a request fails (e.g. connection error).
    """
    results: list[LabelResult] = []
    for name in names:
        try:
            label_id = create_label(client, name, description)
        except FleetAPIError as error:
            results.append(LabelResult(name, None, str(error)))
        else:
            results.append(LabelResult(name, label_id, None))
    return results


def delete_labels(client: httpx.Client, names: Iterable[str]) -> list[LabelResult]:
    """Delete labels by name, continuing past per-label errors.

    Label IDs are fetched once up front. A per-label failure (no label has
    that name, or the label is builtin) is recorded in that label's result
    and does not stop the run.

    Args:
        client: An authenticated client, as returned by
            :func:`fleet_mgmt.auth.build_client`.
        names: Label names to delete, in order.

    Returns:
        One :class:`LabelResult` per name, in the given order.

    Raises:
        InvalidTokenError: If the server responds with HTTP 401.
        RateLimitedError: If the server responds with HTTP 429.
        FleetAPIError: If the label list itself cannot be fetched.
        httpx.HTTPError: If a request fails (e.g. connection error).
    """
    label_ids = fetch_label_ids(client)
    results: list[LabelResult] = []
    for name in names:
        label_id = label_ids.get(name)
        if label_id is None:
            results.append(LabelResult(name, None, f"no label named {name!r}"))
            continue
        try:
            delete_label(client, label_id)
        except FleetAPIError as error:
            results.append(LabelResult(name, label_id, str(error)))
        else:
            results.append(LabelResult(name, label_id, None))
    return results


def _build_arg_parser() -> argparse.ArgumentParser:
    """Build the command-line argument parser for this module.

    Returns:
        A configured ``argparse.ArgumentParser``.
    """
    parser = argparse.ArgumentParser(
        prog="fleet-labels",
        description="Create or delete Fleet manual labels, or add or remove them on hosts.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    for action in LabelAction:
        action_parser = subparsers.add_parser(
            action.value,
            help=f"{action.value.capitalize()} labels on the given hosts.",
        )
        action_parser.add_argument(
            "--label",
            dest="labels",
            action="append",
            default=[],
            required=True,
            metavar="NAME",
            help="A manual label name. Repeat to specify more than one.",
        )
        action_parser.add_argument(
            "hosts",
            nargs="*",
            metavar="HOST",
            help="A host identifier (hostname, hardware serial, or UUID).",
        )
        action_parser.add_argument(
            "--file",
            metavar="PATH",
            help="Read additional host identifiers from PATH, one per line. Use - for stdin.",
        )
        _add_json_flag(action_parser)

    create_parser = subparsers.add_parser(_CREATE, help="Create manual labels.")
    create_parser.add_argument("names", nargs="+", metavar="NAME", help="A label name to create.")
    create_parser.add_argument(
        "--description",
        default="",
        help="A description applied to every created label.",
    )
    _add_json_flag(create_parser)

    delete_parser = subparsers.add_parser(_DELETE, help="Delete labels by name.")
    delete_parser.add_argument("names", nargs="+", metavar="NAME", help="A label name to delete.")
    delete_parser.add_argument(
        "--yes",
        action="store_true",
        help="Confirm the deletion. Required, because deleting a label cannot be undone.",
    )
    _add_json_flag(delete_parser)
    return parser


def _add_json_flag(parser: argparse.ArgumentParser) -> None:
    """Add the shared ``--json`` output flag to a subcommand parser.

    Args:
        parser: The subcommand parser to extend.
    """
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print results as JSON instead of plain text.",
    )


def _read_identifiers_from_file(path: str) -> list[str]:
    """Read host identifiers from a file path or standard input.

    Args:
        path: A filesystem path, or ``-`` to read from standard input.

    Returns:
        The unique, ordered list of host identifiers found in the file.
    """
    if path == "-":
        return read_identifiers(sys.stdin)
    with open(path, encoding="utf-8") as handle:  # noqa: PTH123
        return read_identifiers(handle)


def _validate_args(parser: argparse.ArgumentParser, args: argparse.Namespace) -> list[str]:
    """Check the parsed arguments and collect the items the command acts on.

    Exits through ``parser.error`` (status 2) on a usage error.

    Args:
        parser: The parser, used to report usage errors.
        args: The parsed arguments.

    Returns:
        The unique, ordered host identifiers for ``add``/``remove``, or
        label names for ``create``/``delete``.
    """
    if args.command in {_CREATE, _DELETE}:
        names = read_identifiers(args.names)
        if not names:
            parser.error("no label names given")
        if args.command == _DELETE and not args.yes:
            parser.error("deleting labels cannot be undone; pass --yes to confirm")
        return names

    identifiers = list(args.hosts)
    if args.file:
        identifiers.extend(_read_identifiers_from_file(args.file))
    identifiers = read_identifiers(identifiers)
    if not identifiers:
        parser.error("no hosts given; pass HOST arguments or --file")
    return identifiers


def _run_command(
    client: httpx.Client,
    args: argparse.Namespace,
    items: list[str],
) -> list[HostResult] | list[LabelResult]:
    """Run the chosen subcommand against the Fleet server.

    Args:
        client: An authenticated client.
        args: The parsed arguments.
        items: Host identifiers or label names, from :func:`_validate_args`.

    Returns:
        The per-host or per-label results, in order.
    """
    if args.command == _CREATE:
        return create_labels(client, items, args.description)
    if args.command == _DELETE:
        return delete_labels(client, items)
    return update_labels(client, items, args.labels, LabelAction(args.command))


def _print_text_report(results: list[HostResult] | list[LabelResult]) -> None:
    """Print one line per result, followed by a summary line.

    Args:
        results: The per-host or per-label results to report, in order.
    """
    for result in results:
        if isinstance(result, HostResult):
            subject, detail = result.identifier, f"host {result.host_id}"
        else:
            subject, detail = result.name, f"label {result.label_id}"
        if result.ok:
            print(f"ok   {subject} ({detail})")
        else:
            print(f"FAIL {subject}: {result.error}")
    succeeded = sum(1 for result in results if result.ok)
    print(f"{succeeded} succeeded, {len(results) - succeeded} failed")


def _print_json_report(
    args: argparse.Namespace,
    items: list[str],
    results: list[HostResult] | list[LabelResult],
) -> None:
    """Print a JSON summary of the command and its results.

    Host commands report the labels applied and one entry per host. Label
    commands report one entry per label.

    Args:
        args: The parsed arguments.
        items: Host identifiers or label names the command acted on.
        results: The per-host or per-label results, in order.
    """
    succeeded = sum(1 for result in results if result.ok)
    entries = [_json_entry(result) for result in results]
    labels = items if args.command in {_CREATE, _DELETE} else args.labels
    print(
        json.dumps(
            {
                "action": args.command,
                "labels": labels,
                "succeeded": succeeded,
                "failed": len(results) - succeeded,
                "results": entries,
            },
        ),
    )


def _json_entry(result: HostResult | LabelResult) -> dict[str, object]:
    """Convert one result into its JSON report entry.

    Args:
        result: A per-host or per-label result.

    Returns:
        ``identifier``/``host_id`` for a host result, or ``name``/``label_id``
        for a label result, plus ``ok`` and ``error``.
    """
    if isinstance(result, HostResult):
        return {
            "identifier": result.identifier,
            "host_id": result.host_id,
            "ok": result.ok,
            "error": result.error,
        }
    return {
        "name": result.name,
        "label_id": result.label_id,
        "ok": result.ok,
        "error": result.error,
    }


def main(argv: Sequence[str] | None = None) -> int:
    """Run the ``fleet-labels`` command-line tool.

    Args:
        argv: Command-line arguments, excluding the program name. Defaults
            to ``sys.argv[1:]``.

    Returns:
        A process exit code: ``0`` if every host or label succeeded, ``5``
        if one or more failed, ``2`` for missing credentials or a usage
        error, ``3`` for an invalid or expired token, ``4`` for a
        rate-limited request, and ``1`` for any other API or network error
        that stopped the run.
    """
    parser = _build_arg_parser()
    args = parser.parse_args(argv)
    items = _validate_args(parser, args)

    try:
        credentials = load_credentials()
    except MissingCredentialsError as error:
        print(f"error: {error}", file=sys.stderr)
        return 2

    try:
        with build_client(credentials) as client:
            results = _run_command(client, args, items)
    except InvalidTokenError as error:
        print(f"error: {error}", file=sys.stderr)
        return 3
    except RateLimitedError as error:
        print(f"error: {error}", file=sys.stderr)
        return 4
    except (FleetAPIError, httpx.HTTPError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 1

    if args.json:
        _print_json_report(args, items, results)
    else:
        _print_text_report(results)

    return 0 if all(result.ok for result in results) else 5


if __name__ == "__main__":
    raise SystemExit(main())

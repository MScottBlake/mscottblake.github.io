# fleet-mgmt

Command-line tools and a small Python library for the
[Fleet Device Management](https://fleetdm.com) REST API.

Two commands ship today:

- `fleet-auth` checks that a Fleet API token works.
- `fleet-labels` creates and deletes manual labels, and adds or removes them on hosts.

A local sandbox script (`dev/sandbox.sh`) runs a throwaway Fleet server with fake
hosts, so you can try both commands without touching a real server.

## Requirements

- Python 3.14
- [uv](https://docs.astral.sh/uv/)
- For the sandbox only: macOS with [apple/container](https://github.com/apple/container),
  `curl`, and `jq`

## Setup

```sh
uv sync
export FLEET_URL=https://fleet.example.com
export FLEET_API_TOKEN=xxxxx
```

To get a token as a person, open the Fleet UI, go to "My account", and click
"Get API token". SSO and MFA users must do it this way. For a service account,
run `fleetctl user create --name "svc" --api-only`.

## Check your token

```sh
uv run fleet-auth check
uv run fleet-auth check --json
```

Exit codes: 0 valid, 2 missing or bad credentials, 3 invalid or expired token,
4 rate limited, 1 any other error.

## Manage labels

Hosts can be named by hostname, hardware serial, or UUID.

```sh
# Add or remove labels on hosts
uv run fleet-labels add --label canary web-01 web-02
uv run fleet-labels remove --label canary --label beta web-01

# Read hosts from a file (one per line, # for comments) or stdin
uv run fleet-labels add --label canary --file hosts.txt
cat hosts.txt | uv run fleet-labels add --label canary --file -

# Create and delete manual labels
uv run fleet-labels create canary beta --description "Early rollout ring"
uv run fleet-labels delete canary beta --yes
```

Add `--json` to any command for machine-readable output.

`delete` refuses to run without `--yes`. Deleting a label removes it from every
host and cannot be undone.

Only manual labels work. Fleet rejects dynamic (query-based) and builtin labels
such as `All Hosts`. The token needs the admin, maintainer, technician, or gitops
role. Observers cannot change labels.

One failed host or label does not stop the run. The tool tries every item and
lists the failures at the end. An invalid token, a rate limit, or a network error
stops the run at once, because every remaining item would fail too.

Exit codes: 0 all succeeded, 5 some failed, 2 bad input or `delete` without
`--yes`, 3 invalid token, 4 rate limited, 1 other error.

## Use as a library

```python
from fleet_mgmt.auth import build_client, load_credentials, verify_token
from fleet_mgmt.labels import LabelAction, create_labels, delete_labels, update_labels

with build_client(load_credentials()) as client:
    user = verify_token(client)
    create_labels(client, ["canary"], description="Early rollout ring")
    results = update_labels(client, ["web-01", "web-02"], ["canary"], LabelAction.ADD)
    failed = [r for r in results if not r.ok]
    delete_labels(client, ["canary"])
```

`build_client` returns an `httpx.Client` that sends the token on every request.
You can use it for any other Fleet API call.

## Local sandbox

`dev/sandbox.sh` starts MySQL, Redis, and Fleet as three containers, then seeds
an admin user, the manual labels `canary` and `beta`, and fake hosts.

```sh
dev/sandbox.sh up        # first run takes 1 to 3 minutes
dev/sandbox.sh seed      # HOSTS=100 dev/sandbox.sh seed for more hosts
source dev/.sandbox.env && uv run fleet-labels add --label canary sandbox-mac-001
dev/sandbox.sh status
dev/sandbox.sh down      # deletes everything
```

Fake hosts are named `sandbox-mac-001`, `sandbox-win-002`, `sandbox-linux-003`,
and so on. Serials follow the pattern `SBX0000001`. The web UI is at
http://localhost:8080 (login `admin@sandbox.local` / `sandbox-Admin-123!`).

`dev/.sandbox.env` holds the sandbox token and is gitignored. Source it only in
the command that needs it, so it does not replace your real credentials.

The sandbox uses up to about 1.8 GB of RAM while it runs. Run `down` when you
are done.

## Development

```sh
uv run pytest            # tests, with a 100% branch coverage gate
uv run ruff check .
uv run ruff format --check .
uv run ty check
```

Code lives in `src/fleet_mgmt/`. Tests live in `tests/`, split into unit tests
(`test_*.py`) and regression tests (`test_*_regression.py`).

## Agent skills

`.claude/skills/` holds one skill per tool (`fleet-auth`, `fleet-labels`,
`fleet-sandbox`). They tell AI agents how to call each tool and what to tell the
user when it fails. Add a matching skill when you add a new module.

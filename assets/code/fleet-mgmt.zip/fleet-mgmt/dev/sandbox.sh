#!/usr/bin/env bash
# Run a throwaway Fleet Device Management server with fake hosts on apple/container.
#
# Starts MySQL, Redis, and Fleet as three containers, wires them together by
# container IP, then seeds an admin user, two manual labels, and fake hosts
# inserted straight into MySQL. The fake hosts never check in, so Fleet shows
# them as offline; host lookup and manual labels work normally, which is what
# the fleet-auth and fleet-labels CLIs need.
#
# Nothing is stored on a volume: `down` throws all data away.
#
# Usage:
#   dev/sandbox.sh up          # start containers, wait for Fleet to be healthy
#   dev/sandbox.sh seed        # admin user, labels, fake hosts, dev/.sandbox.env
#   dev/sandbox.sh status      # containers, host count, sample identifiers
#   dev/sandbox.sh down        # delete containers and dev/.sandbox.env
#
# Examples:
#   dev/sandbox.sh up && dev/sandbox.sh seed
#   HOSTS=100 dev/sandbox.sh seed
#   source dev/.sandbox.env && uv run fleet-auth check
#   uv run fleet-labels add --label canary sandbox-mac-001 SBX0000002
#
# Requires: container (apple/container), curl, jq.

set -euo pipefail

readonly FLEET_TAG="v4.92.1"
readonly FLEET_IMAGE="docker.io/fleetdm/fleet:${FLEET_TAG}"
readonly MYSQL_IMAGE="docker.io/library/mysql:8.0"
readonly REDIS_IMAGE="docker.io/library/redis:7"

readonly MYSQL_NAME="fleet-sandbox-mysql"
readonly REDIS_NAME="fleet-sandbox-redis"
readonly SERVER_NAME="fleet-sandbox-server"
readonly PREPARE_NAME="fleet-sandbox-prepare"

readonly DB_NAME="fleet"
readonly DB_USER="fleet"
readonly DB_PASSWORD="fleet"

# Each container is its own VM. A VM keeps any RAM its guest has touched,
# including Linux page cache, so these limits are the worst-case footprint.
readonly MYSQL_MEMORY="768M"
readonly MYSQL_CPUS=1
readonly REDIS_MEMORY="256M"
readonly REDIS_CPUS=1
readonly FLEET_MEMORY="768M"
readonly FLEET_CPUS=2

readonly FLEET_PORT=8080
readonly FLEET_URL="http://localhost:${FLEET_PORT}"
readonly ADMIN_EMAIL="admin@sandbox.local"
readonly ADMIN_PASSWORD="sandbox-Admin-123!"
readonly LABELS=("canary" "beta")

HOSTS="${HOSTS:-25}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
readonly ENV_FILE="${SCRIPT_DIR}/.sandbox.env"

log() { printf '==> %s\n' "$*" >&2; }
die() { printf 'error: %s\n' "$*" >&2; exit 1; }

# Print the IPv4 address of a running container, without the /prefix.
container_ip() {
  container inspect "$1" | jq -r '.[0].networks[0].address' | cut -d/ -f1
}

# Succeed if a container with this name exists, in any state.
container_exists() {
  [[ "$(container inspect "$1" 2>/dev/null | jq 'length')" -gt 0 ]]
}

# Retry a command once per second until it succeeds or the timeout (seconds) runs out.
wait_for() {
  local what="$1" timeout="$2"
  shift 2
  local i
  for ((i = 0; i < timeout; i++)); do
    if "$@" >/dev/null 2>&1; then
      return 0
    fi
    sleep 1
  done
  die "timed out after ${timeout}s waiting for ${what}"
}

mysql_ready() {
  container exec "$MYSQL_NAME" mysql -u"$DB_USER" -p"$DB_PASSWORD" "$DB_NAME" -e 'SELECT 1'
}

fleet_healthy() {
  curl -sf "${FLEET_URL}/healthz"
}

# Run SQL from stdin against the Fleet database.
run_sql() {
  container exec -i "$MYSQL_NAME" mysql -u"$DB_USER" -p"$DB_PASSWORD" "$DB_NAME" 2>/dev/null
}

cmd_up() {
  container system status >/dev/null 2>&1 || container system start --enable-kernel-install

  for name in "$MYSQL_NAME" "$REDIS_NAME" "$SERVER_NAME"; do
    container_exists "$name" && die "$name already exists; run 'dev/sandbox.sh down' first"
  done

  log "Starting MySQL"
  # Binary logging and performance_schema are on by default in MySQL 8 and
  # cost memory and disk writes that a single-node test database never uses.
  container run -d --name "$MYSQL_NAME" -m "$MYSQL_MEMORY" --cpus "$MYSQL_CPUS" \
    -e MYSQL_ROOT_PASSWORD=toor \
    -e MYSQL_DATABASE="$DB_NAME" \
    -e MYSQL_USER="$DB_USER" \
    -e MYSQL_PASSWORD="$DB_PASSWORD" \
    "$MYSQL_IMAGE" mysqld \
    --skip-log-bin \
    --performance-schema=OFF \
    --innodb-buffer-pool-size=64M >/dev/null

  log "Starting Redis"
  container run -d --name "$REDIS_NAME" -m "$REDIS_MEMORY" --cpus "$REDIS_CPUS" \
    "$REDIS_IMAGE" redis-server --save "" --appendonly no >/dev/null

  log "Waiting for MySQL"
  wait_for "MySQL" 180 mysql_ready

  local mysql_ip redis_ip
  mysql_ip="$(container_ip "$MYSQL_NAME")"
  redis_ip="$(container_ip "$REDIS_NAME")"

  # The Fleet image is amd64-only, so these containers run under Rosetta.
  local fleet_env=(
    -e "FLEET_MYSQL_ADDRESS=${mysql_ip}:3306"
    -e "FLEET_MYSQL_DATABASE=${DB_NAME}"
    -e "FLEET_MYSQL_USERNAME=${DB_USER}"
    -e "FLEET_MYSQL_PASSWORD=${DB_PASSWORD}"
    -e "FLEET_REDIS_ADDRESS=${redis_ip}:6379"
    -e "FLEET_SERVER_TLS=false"
  )

  log "Running Fleet database migrations"
  local prepare_log
  if ! prepare_log="$(container run --rm --arch amd64 --name "$PREPARE_NAME" \
    -m "$FLEET_MEMORY" --cpus "$FLEET_CPUS" "${fleet_env[@]}" \
    "$FLEET_IMAGE" fleet prepare db --no-prompt 2>&1)"; then
    printf '%s\n' "$prepare_log" >&2
    die "fleet prepare db failed"
  fi

  log "Starting Fleet ${FLEET_TAG}"
  container run -d --arch amd64 --name "$SERVER_NAME" -p "${FLEET_PORT}:8080" \
    -m "$FLEET_MEMORY" --cpus "$FLEET_CPUS" "${fleet_env[@]}" \
    "$FLEET_IMAGE" fleet serve >/dev/null

  log "Waiting for Fleet at ${FLEET_URL}"
  wait_for "Fleet" 120 fleet_healthy

  log "Fleet is up. Next: dev/sandbox.sh seed"
}

# Print an admin API token: run first-time setup, or log in if setup is done.
admin_token() {
  local body token
  body="$(jq -n \
    --arg email "$ADMIN_EMAIL" --arg password "$ADMIN_PASSWORD" --arg url "$FLEET_URL" \
    '{admin: {admin: true, email: $email, name: "Sandbox Admin",
              password: $password, password_confirmation: $password},
      org_info: {org_name: "Fleet Sandbox"},
      server_url: $url}')"
  token="$(curl -s -X POST "${FLEET_URL}/api/v1/setup" \
    -H 'Content-Type: application/json' -d "$body" | jq -r '.token? // empty' 2>/dev/null || true)"

  if [[ -z "$token" ]]; then
    body="$(jq -n --arg email "$ADMIN_EMAIL" --arg password "$ADMIN_PASSWORD" \
      '{email: $email, password: $password}')"
    token="$(curl -s -X POST "${FLEET_URL}/api/v1/fleet/login" \
      -H 'Content-Type: application/json' -d "$body" | jq -r '.token? // empty' 2>/dev/null || true)"
  fi

  [[ -n "$token" ]] || die "could not get an admin token from Fleet"
  printf '%s' "$token"
}

create_label() {
  local token="$1" name="$2" body status
  body="$(jq -n --arg name "$name" \
    '{name: $name, description: "Sandbox manual label", label_membership_type: "manual", hosts: []}')"
  status="$(curl -s -o /dev/null -w '%{http_code}' -X POST "${FLEET_URL}/api/v1/fleet/labels" \
    -H "Authorization: Bearer ${token}" -H 'Content-Type: application/json' -d "$body")"
  case "$status" in
    200) log "Created label ${name}" ;;
    409) log "Label ${name} already exists" ;;
    *) die "creating label ${name} returned HTTP ${status}" ;;
  esac
}

# Print SQL that inserts $HOSTS fake hosts. Re-running it adds no duplicates.
fake_hosts_sql() {
  local kinds=("mac" "win" "linux")
  local platforms=("darwin" "windows" "ubuntu")
  local os_versions=("macOS 15.5" "Windows 11 Enterprise 24H2" "Ubuntu 24.04.2 LTS")
  local vendors=("Apple Inc." "Dell Inc." "Lenovo")
  local models=("MacBookPro18,3" "Latitude 7440" "ThinkPad X1 Carbon Gen 12")

  local i k n hostname serial uuid
  for ((i = 1; i <= HOSTS; i++)); do
    k=$(((i - 1) % 3))
    n="$(printf '%03d' "$i")"
    hostname="sandbox-${kinds[k]}-${n}"
    serial="$(printf 'SBX%07d' "$i")"
    uuid="$(printf '5A4DB0C5-0000-4000-8000-%012d' "$i")"
    cat <<SQL
INSERT IGNORE INTO hosts
  (osquery_host_id, node_key, hostname, computer_name, uuid, hardware_serial,
   platform, os_version, osquery_version, hardware_vendor, hardware_model,
   primary_ip, detail_updated_at, label_updated_at, policy_updated_at)
VALUES
  ('${uuid}', 'sandbox-node-key-${n}', '${hostname}', '${hostname}', '${uuid}', '${serial}',
   '${platforms[k]}', '${os_versions[k]}', '5.17.0', '${vendors[k]}', '${models[k]}',
   '10.0.0.${i}', NOW(), NOW(), NOW());
SQL
  done

  cat <<'SQL'
INSERT IGNORE INTO host_display_names (host_id, display_name)
  SELECT id, computer_name FROM hosts WHERE hostname LIKE 'sandbox-%';
INSERT IGNORE INTO host_seen_times (host_id, seen_time)
  SELECT id, NOW() FROM hosts WHERE hostname LIKE 'sandbox-%';
SQL
}

cmd_seed() {
  fleet_healthy >/dev/null 2>&1 || die "Fleet is not running; run 'dev/sandbox.sh up' first"

  log "Getting admin API token"
  local token
  token="$(admin_token)"

  for label in "${LABELS[@]}"; do
    create_label "$token" "$label"
  done

  log "Inserting ${HOSTS} fake hosts"
  fake_hosts_sql | run_sql

  cat >"$ENV_FILE" <<ENV
export FLEET_URL=${FLEET_URL}
export FLEET_API_TOKEN=${token}
ENV
  log "Wrote ${ENV_FILE}"
  log "Next: source dev/.sandbox.env && uv run fleet-auth check"
}

cmd_status() {
  container ls -a | grep -E '^(ID|fleet-sandbox-)' || true

  if ! fleet_healthy >/dev/null 2>&1; then
    log "Fleet is not reachable at ${FLEET_URL}"
    return 0
  fi
  [[ -f "$ENV_FILE" ]] || { log "Fleet is up but not seeded"; return 0; }

  local token
  token="$(sed -n 's/^export FLEET_API_TOKEN=//p' "$ENV_FILE")"
  local auth=(-H "Authorization: Bearer ${token}")

  printf '\nHosts: %s\n\n' \
    "$(curl -s "${auth[@]}" "${FLEET_URL}/api/v1/fleet/hosts/count" | jq -r '.count')"
  printf 'Sample identifiers (hostname, serial, uuid):\n'
  curl -s "${auth[@]}" "${FLEET_URL}/api/v1/fleet/hosts?per_page=5&order_key=hostname" |
    jq -r '.hosts[] | "  \(.hostname)  \(.hardware_serial)  \(.uuid)"'
}

cmd_down() {
  local name
  for name in "$SERVER_NAME" "$PREPARE_NAME" "$REDIS_NAME" "$MYSQL_NAME"; do
    if container_exists "$name"; then
      log "Deleting ${name}"
      container stop "$name" >/dev/null 2>&1 || true
      # A delete right after a stop can fail once; retry before giving up.
      container rm -f "$name" >/dev/null 2>&1 || { sleep 2; container rm -f "$name" >/dev/null; }
    fi
  done
  rm -f "$ENV_FILE"
  log "Sandbox removed"
}

main() {
  case "${1:-}" in
    up) cmd_up ;;
    seed) cmd_seed ;;
    status) cmd_status ;;
    down) cmd_down ;;
    *)
      sed -n '2,/^$/s/^# \{0,1\}//p' "${BASH_SOURCE[0]}" >&2
      exit 2
      ;;
  esac
}

main "$@"

---
name: fleet-auth
description: Check or use Fleet Device Management API credentials (FLEET_URL, FLEET_API_TOKEN) via the fleet_mgmt.auth module. Use when asked to verify a Fleet API token, log in to Fleet, check Fleet auth, or build an authenticated Fleet API client.
model: haiku
context: fork
---

# Fleet API authentication

Use the `fleet_mgmt.auth` module to check Fleet credentials or to get an
authenticated `httpx.Client` for other Fleet API calls. This module never
performs email/password login — it only validates a pre-issued API token.

## Required environment variables

- `FLEET_URL`: Fleet server base URL, e.g. `https://fleet.example.com`.
- `FLEET_API_TOKEN`: A Fleet API token.

## Commands

Check the token is valid:

```
uv run fleet-auth check
```

Same check, JSON output (for scripting):

```
uv run fleet-auth check --json
```

## Exit codes

| Code | Meaning                              |
| ---- | ------------------------------------- |
| 0    | Token is valid                        |
| 2    | `FLEET_URL` or `FLEET_API_TOKEN` missing or invalid |
| 3    | Token is invalid or expired           |
| 4    | Rate limited by the Fleet server      |
| 1    | Any other API or network error        |

## JSON output shape

```json
{"id": 1, "name": "Jane Doe", "email": "jane@example.com", "global_role": "admin", "api_only": false}
```

## Using it as a library

```python
from fleet_mgmt.auth import build_client, load_credentials, verify_token

credentials = load_credentials()
with build_client(credentials) as client:
    user = verify_token(client)
    # client is now ready for other Fleet API calls, e.g.:
    # client.get("/api/v1/fleet/hosts")
```

## What to tell the user on failure

- **Exit 2 (missing credentials):** Ask them to set `FLEET_URL` and
  `FLEET_API_TOKEN`.
- **Exit 3 (invalid token):** The token is wrong, revoked, or expired.
  - SSO or MFA (multi-factor authentication) users cannot get a token by
    logging in from a script. Tell them to open the Fleet UI, go to
    "My account", and click "Get API token".
  - For a service account, create a token with
    `fleetctl user create --name "svc" --api-only`.
- **Exit 4 (rate limited):** Wait and retry; the error message includes the
  `Retry-After` seconds when the server sent one.

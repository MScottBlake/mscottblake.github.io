---
name: fleet-labels
description: Create or delete Fleet Device Management manual labels, and add or remove them on hosts, via the fleet_mgmt.labels module. Use when asked to create, make, delete, or remove a Fleet label, or to tag, label, add a label to, or remove a label from one or more Fleet hosts/devices.
model: haiku
context: fork
---

# Fleet labels

Use the `fleet_mgmt.labels` module to create or delete **manual** labels,
and to add or remove them on a set of Fleet hosts. It cannot create or
assign dynamic (query-based) labels, and Fleet refuses to delete builtin
labels such as `All Hosts` or `macOS`.

Requires the same `FLEET_URL` / `FLEET_API_TOKEN` environment variables as
the `fleet-auth` skill. Use that skill first if the token needs checking.

## Commands

Add a label to one or more hosts (accepts hostname, hardware serial, or UUID):

```
uv run fleet-labels add --label canary web-01 web-02
```

Remove labels (repeat `--label` for more than one):

```
uv run fleet-labels remove --label canary --label beta web-01
```

Read hosts from a file (one identifier per line, `#` for comments) or stdin:

```
uv run fleet-labels add --label canary --file hosts.txt
cat hosts.txt | uv run fleet-labels add --label canary --file -
```

Create manual labels (one `--description` applies to all names given):

```
uv run fleet-labels create canary beta --description "Early rollout ring"
```

Delete labels by name. `--yes` is required: deletion cannot be undone and
removes the label from every host that has it. Confirm with the user before
passing `--yes` unless they explicitly asked for the deletion.

```
uv run fleet-labels delete canary beta --yes
```

Add `--json` to any command for machine-readable output.

## Exit codes

| Code | Meaning                                        |
| ---- | ----------------------------------------------- |
| 0    | Every host or label succeeded                    |
| 5    | One or more failed, run completed anyway         |
| 2    | Missing credentials, no hosts/labels given, or `delete` without `--yes` |
| 3    | Token is invalid or expired                      |
| 4    | Rate limited by the Fleet server                 |
| 1    | Other API or network error; run stopped early    |

A per-item failure (host not found, unknown label, dynamic/builtin label,
duplicate name on create) does not stop the run — every host or label is
still attempted, and the failures are listed in the output. Only an invalid
token, a rate limit, or a network error stops the run early, since those
would fail every remaining item anyway.

## JSON output shape

```json
{
  "action": "add",
  "labels": ["canary"],
  "succeeded": 1,
  "failed": 1,
  "results": [
    {"identifier": "web-01", "host_id": 12, "ok": true, "error": null},
    {"identifier": "web-02", "host_id": null, "ok": false, "error": "no host matches identifier 'web-02'"}
  ]
}
```

`create` and `delete` use the same top-level shape, with label entries:

```json
{
  "action": "delete",
  "labels": ["canary", "nope"],
  "succeeded": 1,
  "failed": 1,
  "results": [
    {"name": "canary", "label_id": 21, "ok": true, "error": null},
    {"name": "nope", "label_id": null, "ok": false, "error": "no label named 'nope'"}
  ]
}
```

## Using it as a library

```python
from fleet_mgmt.auth import build_client, load_credentials
from fleet_mgmt.labels import LabelAction, create_labels, delete_labels, update_labels

with build_client(load_credentials()) as client:
    create_labels(client, ["canary"], description="Early rollout ring")
    results = update_labels(client, ["web-01", "web-02"], ["canary"], LabelAction.ADD)
    failed = [r for r in results if not r.ok]
    delete_labels(client, ["canary"])
```

## What to tell the user on failure

- **Label rejected as dynamic/builtin:** Fleet only allows manual labels to
  be assigned this way. Tell the user to check the label's type in the
  Fleet UI, or create a new manual label.
- **Duplicate on create (409):** a label with that name already exists.
  Use it as-is or pick another name.
- **Builtin label on delete (422):** Fleet never allows deleting builtin
  labels.
- **`no label named ...` on delete:** names are exact and case-sensitive.
- **Host not found:** the identifier didn't match any host's hostname,
  serial, or UUID. Suggest double-checking the identifier in the Fleet UI.
- **403 / permission error:** the token's role must be admin, maintainer,
  technician, or gitops — observers cannot modify labels. Creating and
  deleting labels may need admin or maintainer.

To try any of this without touching a real server, use the `fleet-sandbox`
skill.

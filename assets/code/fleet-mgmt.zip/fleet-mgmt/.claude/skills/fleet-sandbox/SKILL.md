---
name: fleet-sandbox
description: Start, seed, inspect, reset, or tear down the local throwaway Fleet Device Management server (dev/sandbox.sh on apple/container) with fake hosts. Use when asked to test fleet-auth, fleet-labels, or any fleet_mgmt script against a real Fleet server, to spin up / reset / stop the Fleet sandbox, or to get fake host identifiers.
model: haiku
context: fork
---

# Fleet sandbox

`dev/sandbox.sh` runs a disposable Fleet server on apple/container
(`container` CLI) so `fleet_mgmt` scripts can be tried against a real API.
It starts three containers (`fleet-sandbox-mysql`, `fleet-sandbox-redis`,
`fleet-sandbox-server`), then seeds an admin user, the manual labels
`canary` and `beta`, and fake hosts written directly into MySQL.

Nothing is on a volume: `down` deletes all data. It is safe to tear down and
rebuild at any time.

## Commands

| Command                   | What it does                                            | Time      |
| ------------------------- | ------------------------------------------------------- | --------- |
| `dev/sandbox.sh up`       | Start containers, run migrations, wait for `/healthz`   | 1–3 min   |
| `dev/sandbox.sh seed`     | Admin, labels, `$HOSTS` fake hosts, `dev/.sandbox.env`  | seconds   |
| `dev/sandbox.sh status`   | Containers, host count, 5 sample identifiers            | seconds   |
| `dev/sandbox.sh down`     | Delete all sandbox containers and `dev/.sandbox.env`    | seconds   |

Run `up` with a long Bash timeout (600000 ms): the first run pulls images and
Fleet runs under Rosetta because its image is amd64-only.

`HOSTS=100 dev/sandbox.sh seed` changes the fake host count (default 25).
`seed` is safe to run again: labels and hosts are not duplicated, and
raising `HOSTS` only adds the missing hosts.

## Standard workflow

1. Check state first: `dev/sandbox.sh status`.
   - No `fleet-sandbox-*` containers → run `up`, then `seed`.
   - Containers running but "not seeded" → run `seed`.
   - "Hosts: N" printed → ready; skip to step 2.
2. Run the script under test. Shell state does not persist between Bash
   calls, so source the env file **in the same command**:

   ```
   source dev/.sandbox.env && uv run fleet-auth check
   source dev/.sandbox.env && uv run fleet-labels add --label canary sandbox-mac-001
   ```
3. Run `dev/sandbox.sh down` when the testing task is done, unless the user
   asks to keep it running. Each container is a VM that holds on to the RAM
   it has used, so an idle sandbox still costs up to ~1.8 GB of the user's
   memory.

Clean reset: `dev/sandbox.sh down && dev/sandbox.sh up && dev/sandbox.sh seed`.

## Fake data

Host `i` (1-based, zero-padded to 3 digits) cycles through three platforms:

| i mod 3 | Hostname             | Platform | Serial       | UUID                                   |
| ------- | -------------------- | -------- | ------------ | -------------------------------------- |
| 1       | `sandbox-mac-001`    | darwin   | `SBX0000001` | `5A4DB0C5-0000-4000-8000-000000000001` |
| 2       | `sandbox-win-002`    | windows  | `SBX0000002` | `5A4DB0C5-0000-4000-8000-000000000002` |
| 0       | `sandbox-linux-003`  | ubuntu   | `SBX0000003` | `5A4DB0C5-0000-4000-8000-000000000003` |

Any of hostname, serial, or UUID works as a `fleet-labels` identifier.
Hosts never check in, so Fleet shows them offline and builtin/dynamic labels
have no members. Manual labels work normally.

Useful labels for testing:
- `canary`, `beta` — manual; assignment succeeds.
- `All Hosts`, `macOS` — builtin/dynamic; Fleet rejects them with 400.
- Any unknown name (e.g. `nope`) — rejected with "Labels not found".

## Credentials and access

- `dev/.sandbox.env` sets `FLEET_URL=http://localhost:8080` and an admin
  `FLEET_API_TOKEN`. It is gitignored. Never commit it or copy the token
  elsewhere.
- Sourcing it overrides any real `FLEET_URL` / `FLEET_API_TOKEN` in that
  command only. Do not export it into a shell the user uses for a real
  Fleet server.
- Web UI: http://localhost:8080, login `admin@sandbox.local` /
  `sandbox-Admin-123!`.
- Raw API check: `source dev/.sandbox.env && curl -s -H "Authorization: Bearer $FLEET_API_TOKEN" "$FLEET_URL/api/v1/fleet/labels/summary" | jq`.
- Direct SQL (custom data):
  `container exec -i fleet-sandbox-mysql mysql -ufleet -pfleet fleet -e 'SELECT id, hostname FROM hosts'`.

## Troubleshooting

| Symptom                                           | Fix                                                                 |
| ------------------------------------------------- | ------------------------------------------------------------------- |
| `fleet-sandbox-... already exists`                | `dev/sandbox.sh down`, then `up`                                    |
| `Fleet is not running; run 'dev/sandbox.sh up'`   | Run `up` (containers are gone, or Fleet crashed — check logs)       |
| `timed out ... waiting for MySQL` / `Fleet`       | `container logs fleet-sandbox-mysql` or `fleet-sandbox-server`, then `down` and retry |
| `fleet prepare db failed`                         | The migration log is printed above; usually MySQL not ready — retry |
| `could not get an admin token from Fleet`         | Setup was done with other credentials; `down` and rebuild           |
| `apiserver is not running`                        | `container system start --enable-kernel-install`                    |
| Port 8080 in use                                  | Stop whatever holds it (`lsof -i :8080`); the port is fixed         |
| `FLEET_URL environment variable is not set`       | `source dev/.sandbox.env &&` was missing from that command          |

If `up` fails, show the user the full output instead of retrying silently.

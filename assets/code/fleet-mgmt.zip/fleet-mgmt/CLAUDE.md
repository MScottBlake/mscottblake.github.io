# Rules for Python modules in this repo

## Runtime and invocation
- Target Python 3.14.
- Every script must be run with `uv` (for example: `uv run script.py`).

## Code style
- Use strict type annotations on all functions, methods, and variables where useful.
- Follow high cohesion and low coupling: each module does one job; modules talk through small, clear interfaces.
- Every module, class, function, and method needs a docstring in Google pydocstyle format.
- Each module docstring must show example invocations (how to run or import and call it).

## Quality gates
- Lint all code with `ruff`.
- Check all type annotations with `ty`.
- Write unit tests and regression tests for every code path.
- Use `pytest` for all tests.

## Skills
- For each new module, create a matching skill so AI agents can invoke it correctly.

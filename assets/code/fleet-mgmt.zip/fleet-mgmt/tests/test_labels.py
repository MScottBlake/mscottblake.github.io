"""Unit tests for fleet_mgmt.labels."""

from __future__ import annotations

import io
import json
from collections.abc import Callable
from pathlib import Path

import httpx
import pytest

from fleet_mgmt import auth, labels

VALID_ENV = {"FLEET_URL": "https://fleet.example.com", "FLEET_API_TOKEN": "secret-token"}

_Handler = Callable[[httpx.Request], httpx.Response]


def _client_for(handler: _Handler) -> httpx.Client:
    credentials = auth.load_credentials(VALID_ENV)
    return auth.build_client(credentials, transport=httpx.MockTransport(handler))


def _host_response(host_id: int) -> httpx.Response:
    return httpx.Response(200, json={"host": {"id": host_id}})


# --- read_identifiers --------------------------------------------------------


def test_read_identifiers_skips_blank_and_comment_lines() -> None:
    lines = ["host-a", "", "  ", "# a comment", "host-b"]
    assert labels.read_identifiers(lines) == ["host-a", "host-b"]


def test_read_identifiers_strips_whitespace() -> None:
    assert labels.read_identifiers(["  host-a  \n"]) == ["host-a"]


def test_read_identifiers_deduplicates_keeping_first_position() -> None:
    assert labels.read_identifiers(["host-a", "host-b", "host-a"]) == ["host-a", "host-b"]


def test_read_identifiers_empty_input() -> None:
    assert labels.read_identifiers([]) == []


# --- resolve_host_id ----------------------------------------------------------


def test_resolve_host_id_success() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/fleet/hosts/identifier/web-01"
        assert request.url.params["exclude_software"] == "true"
        return _host_response(12)

    with _client_for(handler) as client:
        assert labels.resolve_host_id(client, "web-01") == 12


def test_resolve_host_id_not_found() -> None:
    with (
        _client_for(lambda _: httpx.Response(404)) as client,
        pytest.raises(labels.HostNotFoundError, match="web-01"),
    ):
        labels.resolve_host_id(client, "web-01")


def test_resolve_host_id_invalid_token() -> None:
    with (
        _client_for(lambda _: httpx.Response(401)) as client,
        pytest.raises(auth.InvalidTokenError),
    ):
        labels.resolve_host_id(client, "web-01")


def test_resolve_host_id_server_error() -> None:
    with (
        _client_for(lambda _: httpx.Response(500, json={"message": "boom"})) as client,
        pytest.raises(auth.FleetAPIError),
    ):
        labels.resolve_host_id(client, "web-01")


# --- apply_labels ---------------------------------------------------------


def test_apply_labels_add_sends_post_with_body() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/api/v1/fleet/hosts/12/labels"
        assert json.loads(request.content) == {"labels": ["canary"]}
        return httpx.Response(200, json={})

    with _client_for(handler) as client:
        labels.apply_labels(client, 12, ["canary"], labels.LabelAction.ADD)


def test_apply_labels_remove_sends_delete_with_body() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "DELETE"
        assert json.loads(request.content) == {"labels": ["canary"]}
        return httpx.Response(200, json={})

    with _client_for(handler) as client:
        labels.apply_labels(client, 12, ["canary"], labels.LabelAction.REMOVE)


def test_apply_labels_bad_label_raises_api_error() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(400, json={"message": 'Labels not found: "canary".'})

    with (
        _client_for(handler) as client,
        pytest.raises(auth.FleetAPIError, match="Labels not found"),
    ):
        labels.apply_labels(client, 12, ["canary"], labels.LabelAction.ADD)


# --- update_labels -------------------------------------------------------


def test_update_labels_all_succeed() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if "/identifier/" in request.url.path:
            return _host_response(1)
        return httpx.Response(200, json={})

    with _client_for(handler) as client:
        results = labels.update_labels(client, ["a", "b"], ["canary"], labels.LabelAction.ADD)

    assert [r.ok for r in results] == [True, True]
    assert [r.host_id for r in results] == [1, 1]


def test_update_labels_continues_past_per_host_errors() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        path = request.url.path
        if "/identifier/" in path:
            identifier = path.rsplit("/", 1)[-1]
            if identifier == "missing":
                return httpx.Response(404)
            return _host_response(2 if identifier == "bad-label-host" else 1)
        if path == "/api/v1/fleet/hosts/2/labels":
            return httpx.Response(400, json={"message": 'Labels not found: "x".'})
        return httpx.Response(200, json={})

    with _client_for(handler) as client:
        results = labels.update_labels(
            client,
            ["good", "missing", "bad-label-host"],
            ["canary"],
            labels.LabelAction.ADD,
        )

    assert results[0].ok
    assert not results[1].ok
    assert "missing" in str(results[1].error)
    assert not results[2].ok
    assert "Labels not found" in str(results[2].error)


def test_update_labels_stops_on_invalid_token() -> None:
    with (
        _client_for(lambda _: httpx.Response(401)) as client,
        pytest.raises(auth.InvalidTokenError),
    ):
        labels.update_labels(client, ["a", "b"], ["canary"], labels.LabelAction.ADD)


def test_update_labels_stops_on_rate_limit() -> None:
    with (
        _client_for(lambda _: httpx.Response(429)) as client,
        pytest.raises(auth.RateLimitedError),
    ):
        labels.update_labels(client, ["a", "b"], ["canary"], labels.LabelAction.ADD)


def test_update_labels_stops_on_network_error() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("refused")

    with _client_for(handler) as client, pytest.raises(httpx.ConnectError):
        labels.update_labels(client, ["a", "b"], ["canary"], labels.LabelAction.ADD)


# --- main / CLI ------------------------------------------------------------


def _run_main(
    monkeypatch: pytest.MonkeyPatch,
    handler: _Handler,
    argv: list[str],
) -> int:
    monkeypatch.setenv("FLEET_URL", VALID_ENV["FLEET_URL"])
    monkeypatch.setenv("FLEET_API_TOKEN", VALID_ENV["FLEET_API_TOKEN"])
    real_build_client = auth.build_client

    def fake_build_client(credentials: auth.FleetCredentials, **_: object) -> httpx.Client:
        return real_build_client(credentials, transport=httpx.MockTransport(handler))

    monkeypatch.setattr(labels, "build_client", fake_build_client)
    return labels.main(argv)


def _success_handler(request: httpx.Request) -> httpx.Response:
    if "/identifier/" in request.url.path:
        return _host_response(7)
    return httpx.Response(200, json={})


def test_main_add_success_text(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = _run_main(monkeypatch, _success_handler, ["add", "--label", "canary", "web-01"])
    out = capsys.readouterr().out
    assert exit_code == 0
    assert "ok   web-01 (host 7)" in out
    assert "1 succeeded, 0 failed" in out
    assert "secret-token" not in out


def test_main_remove_success_json(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = _run_main(
        monkeypatch,
        _success_handler,
        ["remove", "--label", "canary", "web-01", "--json"],
    )
    out = capsys.readouterr().out
    assert exit_code == 0
    payload = json.loads(out)
    assert payload["action"] == "remove"
    assert payload["succeeded"] == 1
    assert "secret-token" not in out


def test_main_file_from_path(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
) -> None:
    file_path = tmp_path / "hosts.txt"
    file_path.write_text("web-01\n# comment\nweb-02\n")
    exit_code = _run_main(
        monkeypatch,
        _success_handler,
        ["add", "--label", "canary", "--file", str(file_path)],
    )
    out = capsys.readouterr().out
    assert exit_code == 0
    assert "web-01" in out
    assert "web-02" in out


def test_main_file_from_stdin(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.setattr("sys.stdin", io.StringIO("web-01\nweb-02\n"))
    exit_code = _run_main(
        monkeypatch,
        _success_handler,
        ["add", "--label", "canary", "--file", "-"],
    )
    out = capsys.readouterr().out
    assert exit_code == 0
    assert "web-01" in out
    assert "web-02" in out


def test_main_no_hosts_is_usage_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("FLEET_URL", VALID_ENV["FLEET_URL"])
    monkeypatch.setenv("FLEET_API_TOKEN", VALID_ENV["FLEET_API_TOKEN"])
    with pytest.raises(SystemExit) as exc_info:
        labels.main(["add", "--label", "canary"])
    assert exc_info.value.code == 2


def test_main_no_labels_is_usage_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("FLEET_URL", VALID_ENV["FLEET_URL"])
    monkeypatch.setenv("FLEET_API_TOKEN", VALID_ENV["FLEET_API_TOKEN"])
    with pytest.raises(SystemExit) as exc_info:
        labels.main(["add", "web-01"])
    assert exc_info.value.code == 2


def test_main_missing_credentials(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.delenv("FLEET_URL", raising=False)
    monkeypatch.delenv("FLEET_API_TOKEN", raising=False)
    exit_code = labels.main(["add", "--label", "canary", "web-01"])
    assert exit_code == 2
    assert "FLEET_URL" in capsys.readouterr().err


def test_main_invalid_token(monkeypatch: pytest.MonkeyPatch) -> None:
    exit_code = _run_main(
        monkeypatch,
        lambda _: httpx.Response(401),
        ["add", "--label", "canary", "web-01"],
    )
    assert exit_code == 3


def test_main_rate_limited(monkeypatch: pytest.MonkeyPatch) -> None:
    exit_code = _run_main(
        monkeypatch,
        lambda _: httpx.Response(429),
        ["add", "--label", "canary", "web-01"],
    )
    assert exit_code == 4


def test_main_network_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("refused")

    exit_code = _run_main(monkeypatch, handler, ["add", "--label", "canary", "web-01"])
    assert exit_code == 1


def test_main_partial_failure_exit_code(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if "/identifier/" in request.url.path:
            return httpx.Response(404)
        return httpx.Response(200, json={})

    exit_code = _run_main(monkeypatch, handler, ["add", "--label", "canary", "web-01"])
    assert exit_code == 5


# --- create_label / create_labels -------------------------------------------


def _summary_response(names_to_ids: dict[str, int]) -> httpx.Response:
    entries = [{"id": label_id, "name": name} for name, label_id in names_to_ids.items()]
    return httpx.Response(200, json={"labels": entries})


def test_create_label_sends_manual_label_body() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "POST"
        assert request.url.path == "/api/v1/fleet/labels"
        assert json.loads(request.content) == {
            "name": "canary",
            "description": "Early ring",
            "label_membership_type": "manual",
        }
        return httpx.Response(200, json={"label": {"id": 21, "name": "canary"}})

    with _client_for(handler) as client:
        assert labels.create_label(client, "canary", "Early ring") == 21


def test_create_label_default_description_is_empty() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert json.loads(request.content)["description"] == ""
        return httpx.Response(200, json={"label": {"id": 1}})

    with _client_for(handler) as client:
        labels.create_label(client, "canary")


def test_create_label_duplicate_raises_api_error() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(409, json={"message": "Validation Failed"})

    with _client_for(handler) as client, pytest.raises(auth.FleetAPIError) as exc_info:
        labels.create_label(client, "canary")
    assert exc_info.value.status_code == 409


def test_create_labels_continues_past_per_label_errors() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if json.loads(request.content)["name"] == "taken":
            return httpx.Response(409, json={"message": "Validation Failed"})
        return httpx.Response(200, json={"label": {"id": 30}})

    with _client_for(handler) as client:
        results = labels.create_labels(client, ["taken", "fresh"], "desc")

    assert [result.name for result in results] == ["taken", "fresh"]
    assert not results[0].ok
    assert results[0].label_id is None
    assert results[0].error is not None
    assert "409" in results[0].error
    assert results[1].ok
    assert results[1].label_id == 30


def test_create_labels_stops_on_invalid_token() -> None:
    with (
        _client_for(lambda _: httpx.Response(401)) as client,
        pytest.raises(auth.InvalidTokenError),
    ):
        labels.create_labels(client, ["a", "b"])


# --- fetch_label_ids / delete_label / delete_labels -------------------------


def test_fetch_label_ids_maps_names_to_ids() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/fleet/labels/summary"
        return _summary_response({"canary": 19, "All Hosts": 11})

    with _client_for(handler) as client:
        assert labels.fetch_label_ids(client) == {"canary": 19, "All Hosts": 11}


def test_delete_label_sends_delete_by_id() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "DELETE"
        assert request.url.path == "/api/v1/fleet/labels/id/19"
        return httpx.Response(200, json={})

    with _client_for(handler) as client:
        labels.delete_label(client, 19)


def test_delete_label_builtin_raises_api_error() -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(422, json={"message": "Validation Failed"})

    with _client_for(handler) as client, pytest.raises(auth.FleetAPIError) as exc_info:
        labels.delete_label(client, 11)
    assert exc_info.value.status_code == 422


def test_delete_labels_reports_unknown_builtin_and_success() -> None:
    deleted: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/summary"):
            return _summary_response({"canary": 19, "All Hosts": 11})
        deleted.append(request.url.path)
        if request.url.path.endswith("/11"):
            return httpx.Response(422, json={"message": "Validation Failed"})
        return httpx.Response(200, json={})

    with _client_for(handler) as client:
        results = labels.delete_labels(client, ["nope", "All Hosts", "canary"])

    assert deleted == ["/api/v1/fleet/labels/id/11", "/api/v1/fleet/labels/id/19"]
    nope, builtin, canary = results
    assert not nope.ok
    assert nope.label_id is None
    assert nope.error == "no label named 'nope'"
    assert not builtin.ok
    assert builtin.label_id == 11
    assert canary.ok
    assert canary.label_id == 19


def test_delete_labels_summary_failure_raises() -> None:
    with (
        _client_for(lambda _: httpx.Response(500, json={"message": "boom"})) as client,
        pytest.raises(auth.FleetAPIError),
    ):
        labels.delete_labels(client, ["canary"])


def test_delete_labels_stops_on_rate_limit() -> None:
    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/summary"):
            return _summary_response({"a": 1, "b": 2})
        return httpx.Response(429)

    with _client_for(handler) as client, pytest.raises(auth.RateLimitedError):
        labels.delete_labels(client, ["a", "b"])


# --- main / CLI: create and delete ------------------------------------------


def _label_handler(request: httpx.Request) -> httpx.Response:
    if request.method == "POST":
        return httpx.Response(200, json={"label": {"id": 21}})
    if request.url.path.endswith("/summary"):
        return _summary_response({"canary": 21})
    return httpx.Response(200, json={})


def test_main_create_success_text(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = _run_main(
        monkeypatch,
        _label_handler,
        ["create", "canary", "--description", "Early ring"],
    )
    out = capsys.readouterr().out
    assert exit_code == 0
    assert "ok   canary (label 21)" in out
    assert "1 succeeded, 0 failed" in out


def test_main_create_duplicate_names_created_once(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = _run_main(monkeypatch, _label_handler, ["create", "canary", "canary"])
    assert exit_code == 0
    assert "1 succeeded, 0 failed" in capsys.readouterr().out


def test_main_create_blank_names_is_usage_error(monkeypatch: pytest.MonkeyPatch) -> None:
    with pytest.raises(SystemExit) as exc_info:
        _run_main(monkeypatch, _label_handler, ["create", "  "])
    assert exc_info.value.code == 2


def test_main_create_no_names_is_usage_error(monkeypatch: pytest.MonkeyPatch) -> None:
    with pytest.raises(SystemExit) as exc_info:
        _run_main(monkeypatch, _label_handler, ["create"])
    assert exc_info.value.code == 2


def test_main_delete_success_json(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = _run_main(monkeypatch, _label_handler, ["delete", "canary", "--yes", "--json"])
    payload = json.loads(capsys.readouterr().out)
    assert exit_code == 0
    assert payload == {
        "action": "delete",
        "labels": ["canary"],
        "succeeded": 1,
        "failed": 0,
        "results": [{"name": "canary", "label_id": 21, "ok": True, "error": None}],
    }


def test_main_delete_without_yes_is_usage_error(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        pytest.fail("no request may be sent without --yes")

    with pytest.raises(SystemExit) as exc_info:
        _run_main(monkeypatch, handler, ["delete", "canary"])
    assert exc_info.value.code == 2
    assert "--yes" in capsys.readouterr().err


def test_main_delete_unknown_label_exit_code_and_text(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = _run_main(monkeypatch, _label_handler, ["delete", "nope", "--yes"])
    out = capsys.readouterr().out
    assert exit_code == 5
    assert "FAIL nope: no label named 'nope'" in out


def test_main_delete_summary_error_exit_code(monkeypatch: pytest.MonkeyPatch) -> None:
    exit_code = _run_main(
        monkeypatch,
        lambda _: httpx.Response(500, json={"message": "boom"}),
        ["delete", "canary", "--yes"],
    )
    assert exit_code == 1


def test_main_add_json_keeps_host_shape(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    _run_main(monkeypatch, _success_handler, ["add", "--label", "canary", "web-01", "--json"])
    payload = json.loads(capsys.readouterr().out)
    assert payload["labels"] == ["canary"]
    assert payload["results"] == [{"identifier": "web-01", "host_id": 7, "ok": True, "error": None}]

"""Unit tests for fleet_mgmt.auth."""

from __future__ import annotations

import json
from collections.abc import Callable

import httpx
import pytest

from fleet_mgmt import auth

VALID_ENV = {"FLEET_URL": "https://fleet.example.com", "FLEET_API_TOKEN": "secret-token"}

USER_BODY = {
    "user": {
        "id": 1,
        "name": "Jane Doe",
        "email": "jane@example.com",
        "global_role": "admin",
        "api_only": False,
    },
}

_Handler = Callable[[httpx.Request], httpx.Response]


def _mock_transport(handler: _Handler) -> httpx.MockTransport:
    return httpx.MockTransport(handler)


def _client_for(handler: _Handler, credentials: auth.FleetCredentials) -> httpx.Client:
    return auth.build_client(credentials, transport=_mock_transport(handler))


# --- load_credentials -------------------------------------------------------


def test_load_credentials_success() -> None:
    credentials = auth.load_credentials(VALID_ENV)
    assert credentials.base_url == "https://fleet.example.com"
    assert credentials.token == "secret-token"


def test_load_credentials_strips_trailing_slash() -> None:
    env = {**VALID_ENV, "FLEET_URL": "https://fleet.example.com/"}
    credentials = auth.load_credentials(env)
    assert credentials.base_url == "https://fleet.example.com"


def test_load_credentials_missing_url() -> None:
    env = {"FLEET_API_TOKEN": "secret-token"}
    with pytest.raises(auth.MissingCredentialsError, match="FLEET_URL"):
        auth.load_credentials(env)


def test_load_credentials_blank_url() -> None:
    env = {**VALID_ENV, "FLEET_URL": "   "}
    with pytest.raises(auth.MissingCredentialsError, match="FLEET_URL"):
        auth.load_credentials(env)


def test_load_credentials_bad_scheme() -> None:
    env = {**VALID_ENV, "FLEET_URL": "ftp://fleet.example.com"}
    with pytest.raises(auth.MissingCredentialsError, match="http"):
        auth.load_credentials(env)


def test_load_credentials_no_host() -> None:
    env = {**VALID_ENV, "FLEET_URL": "https://"}
    with pytest.raises(auth.MissingCredentialsError, match="http"):
        auth.load_credentials(env)


def test_load_credentials_missing_token() -> None:
    env = {"FLEET_URL": "https://fleet.example.com"}
    with pytest.raises(auth.MissingCredentialsError, match="FLEET_API_TOKEN"):
        auth.load_credentials(env)


def test_load_credentials_blank_token() -> None:
    env = {**VALID_ENV, "FLEET_API_TOKEN": "  "}
    with pytest.raises(auth.MissingCredentialsError, match="FLEET_API_TOKEN"):
        auth.load_credentials(env)


# --- auth_headers / build_client --------------------------------------------


def test_auth_headers() -> None:
    credentials = auth.FleetCredentials(base_url="https://fleet.example.com", token="secret")
    headers = auth.auth_headers(credentials)
    assert headers["Authorization"] == "Bearer secret"
    assert headers["Accept"] == "application/json"


def test_build_client_sets_base_url_and_headers() -> None:
    credentials = auth.FleetCredentials(base_url="https://fleet.example.com", token="secret")
    client = auth.build_client(credentials)
    try:
        assert str(client.base_url) == "https://fleet.example.com"
        assert client.headers["authorization"] == "Bearer secret"
    finally:
        client.close()


# --- verify_token / _raise_for_status ---------------------------------------


def test_verify_token_success() -> None:
    credentials = auth.load_credentials(VALID_ENV)

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/v1/fleet/me"
        assert request.headers["authorization"] == "Bearer secret-token"
        return httpx.Response(200, json=USER_BODY)

    with _client_for(handler, credentials) as client:
        user = auth.verify_token(client)

    assert user == auth.FleetUser(
        id=1,
        name="Jane Doe",
        email="jane@example.com",
        global_role="admin",
        api_only=False,
    )


def test_verify_token_invalid_token() -> None:
    credentials = auth.load_credentials(VALID_ENV)

    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(401, json={"message": "Authentication required"})

    with _client_for(handler, credentials) as client, pytest.raises(auth.InvalidTokenError):
        auth.verify_token(client)


def test_verify_token_rate_limited_with_retry_after() -> None:
    credentials = auth.load_credentials(VALID_ENV)

    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(429, headers={"Retry-After": "12"})

    with (
        _client_for(handler, credentials) as client,
        pytest.raises(auth.RateLimitedError) as exc_info,
    ):
        auth.verify_token(client)
    assert exc_info.value.retry_after == 12.0


def test_verify_token_rate_limited_without_retry_after() -> None:
    credentials = auth.load_credentials(VALID_ENV)

    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(429)

    with (
        _client_for(handler, credentials) as client,
        pytest.raises(auth.RateLimitedError) as exc_info,
    ):
        auth.verify_token(client)
    assert exc_info.value.retry_after is None


def test_verify_token_server_error_json_body() -> None:
    credentials = auth.load_credentials(VALID_ENV)

    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(500, json={"message": "internal error"})

    with (
        _client_for(handler, credentials) as client,
        pytest.raises(auth.FleetAPIError) as exc_info,
    ):
        auth.verify_token(client)
    assert exc_info.value.status_code == 500
    assert "internal error" in str(exc_info.value)


def test_verify_token_server_error_non_json_body() -> None:
    credentials = auth.load_credentials(VALID_ENV)

    def handler(_: httpx.Request) -> httpx.Response:
        return httpx.Response(503, text="Service Unavailable")

    with (
        _client_for(handler, credentials) as client,
        pytest.raises(auth.FleetAPIError) as exc_info,
    ):
        auth.verify_token(client)
    assert exc_info.value.status_code == 503
    assert "Service Unavailable" in str(exc_info.value)


@pytest.mark.parametrize(
    ("body", "expected"),
    [
        (
            {"message": "Bad request", "errors": [{"name": "base", "reason": "Labels not found"}]},
            "Bad request: Labels not found",
        ),
        (
            {"message": "Bad request", "errors": [{"reason": "first"}, {"reason": "second"}]},
            "Bad request: first; second",
        ),
        ({"errors": [{"reason": "only reason"}]}, "only reason"),
        ({"message": "Bad request", "errors": []}, "Bad request"),
        ({"message": "Bad request", "errors": "not a list"}, "Bad request"),
        ({"message": "Bad request", "errors": ["text", {"name": "base"}]}, "Bad request"),
        ({"message": "Bad request", "errors": [{"reason": ""}]}, "Bad request"),
        ({"message": None, "errors": None}, None),
        ({}, None),
    ],
)
def test_error_message(body: dict[str, object], expected: str | None) -> None:
    assert auth._error_message(body) == expected


@pytest.mark.parametrize("json_body", [{}, [1, 2], 42])
def test_raise_for_status_falls_back_to_raw_text(json_body: object) -> None:
    response = httpx.Response(400, json=json_body)
    with pytest.raises(auth.FleetAPIError) as exc_info:
        auth.raise_for_status(response)
    assert str(exc_info.value) == f"Fleet API error (400): {response.text}"


# --- main / CLI --------------------------------------------------------------


def _run_main(
    monkeypatch: pytest.MonkeyPatch,
    handler: _Handler,
    argv: list[str],
) -> int:
    monkeypatch.setenv("FLEET_URL", VALID_ENV["FLEET_URL"])
    monkeypatch.setenv("FLEET_API_TOKEN", VALID_ENV["FLEET_API_TOKEN"])
    real_build_client = auth.build_client

    def fake_build_client(
        credentials: auth.FleetCredentials,
        **_: object,
    ) -> httpx.Client:
        return real_build_client(credentials, transport=_mock_transport(handler))

    monkeypatch.setattr(auth, "build_client", fake_build_client)
    return auth.main(argv)


def test_main_check_success_text(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = _run_main(monkeypatch, lambda _: httpx.Response(200, json=USER_BODY), ["check"])
    out = capsys.readouterr().out
    assert exit_code == 0
    assert "Jane Doe" in out
    assert "secret-token" not in out


def test_main_check_success_json(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = _run_main(
        monkeypatch,
        lambda _: httpx.Response(200, json=USER_BODY),
        ["check", "--json"],
    )
    out = capsys.readouterr().out
    assert exit_code == 0
    payload = json.loads(out)
    assert payload["email"] == "jane@example.com"
    assert "secret-token" not in out


def test_main_default_command_is_check(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    exit_code = _run_main(monkeypatch, lambda _: httpx.Response(200, json=USER_BODY), [])
    assert exit_code == 0
    assert "Jane Doe" in capsys.readouterr().out


def test_main_missing_credentials(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    monkeypatch.delenv("FLEET_URL", raising=False)
    monkeypatch.delenv("FLEET_API_TOKEN", raising=False)
    exit_code = auth.main(["check"])
    assert exit_code == 2
    assert "FLEET_URL" in capsys.readouterr().err


def test_main_invalid_token(monkeypatch: pytest.MonkeyPatch) -> None:
    exit_code = _run_main(monkeypatch, lambda _: httpx.Response(401), ["check"])
    assert exit_code == 3


def test_main_rate_limited(monkeypatch: pytest.MonkeyPatch) -> None:
    exit_code = _run_main(monkeypatch, lambda _: httpx.Response(429), ["check"])
    assert exit_code == 4


def test_main_other_api_error(monkeypatch: pytest.MonkeyPatch) -> None:
    exit_code = _run_main(monkeypatch, lambda _: httpx.Response(500), ["check"])
    assert exit_code == 1


def test_main_network_error(monkeypatch: pytest.MonkeyPatch) -> None:
    def handler(_: httpx.Request) -> httpx.Response:
        raise httpx.ConnectError("connection refused")

    exit_code = _run_main(monkeypatch, handler, ["check"])
    assert exit_code == 1

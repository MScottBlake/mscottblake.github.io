"""Regression tests for fleet_mgmt.auth.

Each test pins down a specific Fleet API quirk or a past mistake so it
cannot silently come back.
"""

from __future__ import annotations

import httpx
import pytest

from fleet_mgmt import auth


def test_error_reason_from_errors_list_reaches_message() -> None:
    """Fleet puts the cause in errors[].reason; message alone is only "Bad request".

    Body captured from Fleet v4.92.1 for POST /api/v1/fleet/hosts/{id}/labels.
    """
    body = {
        "message": "Bad request",
        "errors": [
            {
                "name": "base",
                "reason": (
                    'Couldn\'t add labels. Labels not found: "nope". All labels must '
                    "exist and be either global or on the same team as the host."
                ),
            },
        ],
        "uuid": "ca7d977b-69e5-4310-842e-6750a5f85e00",
    }
    with pytest.raises(auth.FleetAPIError) as exc_info:
        auth.raise_for_status(httpx.Response(400, json=body))
    assert 'Bad request: Couldn\'t add labels. Labels not found: "nope".' in str(exc_info.value)


def test_credentials_repr_hides_token() -> None:
    """The token must never appear in logs or tracebacks via repr()."""
    credentials = auth.FleetCredentials(base_url="https://fleet.example.com", token="super-secret")
    assert "super-secret" not in repr(credentials)


def test_parse_user_defaults_api_only_to_false() -> None:
    """Older Fleet servers may omit api_only for regular (non-service) users."""
    user = auth._parse_user(
        {"id": 2, "name": "Bob", "email": "bob@example.com", "global_role": "observer"},
    )
    assert user.api_only is False


def test_parse_user_handles_null_global_role() -> None:
    """A user with only team-level roles has a null global_role, not a missing key."""
    user = auth._parse_user(
        {
            "id": 3,
            "name": "Team Member",
            "email": "member@example.com",
            "global_role": None,
            "api_only": False,
        },
    )
    assert user.global_role is None


def test_load_credentials_uses_os_environ_by_default(monkeypatch: pytest.MonkeyPatch) -> None:
    """Calling load_credentials() with no argument must read the real environment."""
    monkeypatch.setenv("FLEET_URL", "https://fleet.example.com")
    monkeypatch.setenv("FLEET_API_TOKEN", "env-token")
    credentials = auth.load_credentials()
    assert credentials.base_url == "https://fleet.example.com"
    assert credentials.token == "env-token"

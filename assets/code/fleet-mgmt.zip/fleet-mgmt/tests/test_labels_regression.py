"""Regression tests for fleet_mgmt.labels.

Each test pins down a specific Fleet API quirk or a past mistake so it
cannot silently come back.
"""

from __future__ import annotations

import json
from collections.abc import Callable

import httpx

from fleet_mgmt import auth, labels

VALID_ENV = {"FLEET_URL": "https://fleet.example.com", "FLEET_API_TOKEN": "secret-token"}

_Handler = Callable[[httpx.Request], httpx.Response]


def _client_for(handler: _Handler) -> httpx.Client:
    credentials = auth.load_credentials(VALID_ENV)
    return auth.build_client(credentials, transport=httpx.MockTransport(handler))


def test_resolve_host_id_url_encodes_identifier() -> None:
    """A hostname with '/', spaces, or '#' must stay a single path segment."""
    identifier = "host/with space#1"

    def handler(request: httpx.Request) -> httpx.Response:
        assert "identifier/host%2Fwith%20space%231" in str(request.url)
        return httpx.Response(200, json={"host": {"id": 9}})

    with _client_for(handler) as client:
        assert labels.resolve_host_id(client, identifier) == 9


def test_resolve_host_id_numeric_hostname_uses_identifier_lookup() -> None:
    """An all-digit hostname must still be resolved via /identifier/, not treated as a host ID."""

    def handler(request: httpx.Request) -> httpx.Response:
        assert "/hosts/identifier/12345" in str(request.url)
        return httpx.Response(200, json={"host": {"id": 999}})

    with _client_for(handler) as client:
        assert labels.resolve_host_id(client, "12345") == 999


def test_apply_labels_remove_request_carries_json_body() -> None:
    """httpx.Client.delete() cannot send a body; apply_labels must use request() instead."""

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.method == "DELETE"
        assert request.content
        assert json.loads(request.content) == {"labels": ["canary", "beta"]}
        return httpx.Response(200, json={})

    with _client_for(handler) as client:
        labels.apply_labels(client, 1, ["canary", "beta"], labels.LabelAction.REMOVE)


def test_dynamic_label_error_message_is_preserved_in_result() -> None:
    """Fleet's 'Labels are dynamic' message must reach the caller via HostResult.error."""
    message = (
        'Couldn\'t add labels. Labels are dynamic: "All Hosts". '
        "Dynamic labels can not be assigned to hosts manually."
    )

    def handler(request: httpx.Request) -> httpx.Response:
        if "/identifier/" in request.url.path:
            return httpx.Response(200, json={"host": {"id": 1}})
        return httpx.Response(
            400,
            json={"message": "Bad request", "errors": [{"name": "base", "reason": message}]},
        )

    with _client_for(handler) as client:
        results = labels.update_labels(client, ["host-a"], ["All Hosts"], labels.LabelAction.ADD)

    assert not results[0].ok
    assert results[0].error is not None
    assert "dynamic" in results[0].error


def test_duplicate_cli_identifier_is_processed_once() -> None:
    """CLI callers may repeat a host by accident; it must only be resolved once."""
    call_count = 0

    def handler(request: httpx.Request) -> httpx.Response:
        nonlocal call_count
        if "/identifier/" in request.url.path:
            call_count += 1
            return httpx.Response(200, json={"host": {"id": 1}})
        return httpx.Response(200, json={})

    with _client_for(handler) as client:
        identifiers = labels.read_identifiers(["host-a", "host-a"])
        results = labels.update_labels(client, identifiers, ["canary"], labels.LabelAction.ADD)

    assert call_count == 1
    assert len(results) == 1


def test_host_result_ok_is_false_when_error_is_set() -> None:
    """HostResult.ok must derive from the error field, not a separately tracked flag."""
    result = labels.HostResult(identifier="host-a", host_id=None, error="boom")
    assert result.ok is False


def test_host_result_ok_is_true_when_error_is_none() -> None:
    result = labels.HostResult(identifier="host-a", host_id=5, error=None)
    assert result.ok is True


def test_delete_label_with_slash_in_name_uses_id_route() -> None:
    """Fleet's by-name DELETE route returns a bare 404 for names containing '/'.

    Deleting by ID must be used so such labels can still be removed.
    """
    paths: list[str] = []

    def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path.endswith("/summary"):
            return httpx.Response(200, json={"labels": [{"id": 23, "name": "a b/c"}]})
        paths.append(request.url.path)
        return httpx.Response(200, json={})

    with _client_for(handler) as client:
        results = labels.delete_labels(client, ["a b/c"])

    assert results[0].ok
    assert paths == ["/api/v1/fleet/labels/id/23"]


def test_label_result_ok_reflects_error() -> None:
    assert labels.LabelResult("canary", 1, None).ok
    assert not labels.LabelResult("canary", None, "boom").ok
